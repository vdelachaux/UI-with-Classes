# Description

The `formGetInstance` method returns, if it exists, the instance of the form controller class created by the [formMethod](formMethod.md) method on its first call. 
